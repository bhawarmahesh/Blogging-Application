CREATE DATABASE blogging_app;

USE blogging_app;