
package com.blogging.bloggingapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import com.blogging.bloggingapp.model.Post;
import com.blogging.bloggingapp.repository.PostRepo;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;



@Controller
public class PostController {

    @Autowired
    PostRepo repo;

    // Display all posts
    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("posts", repo.findAll());
        return "index";
    }

    @GetMapping("/new")
    public String newPost(Model model) {
        model.addAttribute("post", new Post());
        return "new-post";
    }


    @PostMapping("/save")
    public String savePPost(@ModelAttribute("post") Post post) {
        repo.save(post);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String editPOst(@PathVariable int id , Model model)
    {
        Post post = repo.findById(id).orElse(null);
        model.addAttribute("post", post);
        return "edit-post";
    }

    @PostMapping("/update")
    public String updatePost( @ModelAttribute("post") Post post) {
        repo.save(post);
        return "redirect:/";
    }

    
 
    @PostMapping("/delete/{id}")
    public String deletePost(@PathVariable int id) {
        repo.deleteById(id);
        return "redirect:/";
    }

}