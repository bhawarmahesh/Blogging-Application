package com.blogging.bloggingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.blogging.bloggingapp.model.Post;

public interface PostRepo extends JpaRepository<Post, Integer> {

}